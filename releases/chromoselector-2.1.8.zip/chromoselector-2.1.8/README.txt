Thank you for purchasing a licensed copy of chromoselector!

To view the documentation, which includes a detailed reference, a getting-started
guide, examples and JavaScript sandboxes, please open the "docs/index.html"
file with your browser.

A "hello-world.html" file, which can be found in this folder, is also
available and it shows the minimal setup to get chromoselector up and running.

For technical support, do not hesitate to contact support@chromoselector.com
For any other inquiry, please contact info@chromoselector.com
